create view spending_patterns(hire_date, salary, spending_pattern) as
SELECT e1.hire_date,
       e1.salary,
       (SELECT sum(e2.salary) AS sum
        FROM employees e2
        WHERE e2.hire_date >= (e1.hire_date - 90)
          AND e2.hire_date <= e1.hire_date) AS spending_pattern
FROM employees e1;

alter table spending_patterns
    owner to dbmasteruser;

